class up:
  def __init__(self):
    self.val = [0, -1]

class down:
  def __init__(self):
    self.val = [0, 1]

class left:
  def __init__(self):
    self.val = [-1, 0]

class right:
  def __init__(self):
    self.val = [1, 0]